//This is an example code to understand HTTP Requests//
import React, { Component } from 'react';
//import react in our code.

import { StyleSheet, View, Button, Alert } from 'react-native';
//import all the components we are going to use.

export default class App extends Component {
  getDataUsingGet() {
    //GET request
    fetch('http://api.openweathermap.org/data/2.5/weather?q=Dallas&appid=2909e5f110bd59507e4e5e1f3cd38840', {
      method: 'GET',
      //Request Type
    })
      .then(response => {return response.json();})
      //If response is in json then in success
      .then(function(response){
        //Success
        console.log(response.weather.description);
      })
      //If response is not in json then in error
      .catch(error => {
        //Error
        alert(JSON.stringify(error));
        console.error(error);
      });
  }

  render() {
    return (
      <View style={styles.MainContainer}>

        {/*Running POST Request*/}
        <Button title="Get Data Using GET" onPress={this.getDataUsingGet} />
      </View>
    );
  }
}
const styles = StyleSheet.create({
  MainContainer: {
    justifyContent: 'center',
    flex: 1,
    margin: 10,
  },
});
